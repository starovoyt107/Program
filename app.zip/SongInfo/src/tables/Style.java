package tables;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "Style")
public class Style {

	public Style() {

	}

	public Style(String nameRus, String nameEng) {
		this.nameRus = nameRus;
		this.nameEng = nameEng;
	}

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "style_id")
	private Long id;

	@Column(name = "Style_Name_rus", nullable = false)
	private String nameRus;

	@Column(name = "Style_Name_eng", nullable = false)
	private String nameEng;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinTable(name = "Styles_Songs", joinColumns = @JoinColumn(name = "style_id"), inverseJoinColumns = @JoinColumn(name = "song_id"))
	private Set<Song> songs;

	public Set<Song> getSongs() {
		return songs;
	}

	public void setSongs(Set<Song> songs) {
		this.songs = songs;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNameRus() {
		return nameRus;
	}

	public void setNameRus(String nameRus) {
		this.nameRus = nameRus;
	}

	public String getNameEng() {
		return nameEng;
	}

	public void setNameEng(String nameEng) {
		this.nameEng = nameEng;
	}

	@Override
	public String toString() {
		return this.nameRus;
	}
}
