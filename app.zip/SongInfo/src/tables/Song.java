package tables;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "Song")
public class Song {

	public Song() {

	}

	public Song(String name, String performer, String trackLength, Style style,
			User user) {
		this.name = name;
		this.performer = performer;
		this.style = style;
		this.trackLength = trackLength;
		this.user = user;
	}

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "song_id")
	private Long id;

	@Column(name = "Song_name", nullable=false)
	private String name;

	@Column(name = "Performer", nullable=false)
	private String performer;

	@Column(name = "Track_length", nullable=false)
	private String trackLength;

	@ManyToOne
	@JoinColumn(name = "style_id", nullable=false)
	private Style style;

	@ManyToOne
	@JoinColumn(name = "user_id", nullable=false)
	private User user;
	
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinTable(
            name="Commentaries",
            joinColumns = @JoinColumn( name="song_id"),
            inverseJoinColumns = @JoinColumn( name="comment_id")
    )
	private Set<Commentary> commentaries;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPerformer() {
		return performer;
	}

	public void setPerformer(String performer) {
		this.performer = performer;
	}

	public String getTrackLength() {
		return trackLength;
	}

	public void setTrackLength(String trackLength) {
		this.trackLength = trackLength;
	}

	public Style getStyle() {
		return style;
	}

	public void setStyle(Style style) {
		this.style = style;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	@Override
	public String toString(){
		return this.performer+" - "+this.name;
	}
}
