package courseterm;

import java.sql.SQLException;
import java.util.List;

import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;

import tables.Commentary;
import tables.Song;
import tables.Style;
import tables.User;

import dao.HibernateUtil;

public class Database {
	private static SessionFactory sessionFactory;
	private static ServiceRegistry serviceRegistry;
	private String commitStatus = "update";
	private String status;
	public boolean connected = false;
	private String login;
	private static Database instance;

	public Database(String login, String password) {
		connect(login, password);
	}

	public Database() {
	}

	public void connect(String login, String password)
			throws ExceptionInInitializerError {
		this.login = login;
		Configuration config = new Configuration();
		config.configure("hibernate.cfg.xml");
		config.setProperty("hibernate.connection.username", login);
		config.setProperty("hibernate.connection.password", password);
		config.setProperty("hibernate.hbm2ddl.auto", commitStatus);
		try {
			serviceRegistry = new StandardServiceRegistryBuilder()
					.applySettings(config.getProperties()).build();
			sessionFactory = config.buildSessionFactory(serviceRegistry);
			connected = true;
			setStatus("Соединение успешно");
		} catch (Throwable ex) {
			connected = false;
			setStatus("Неудалось создать объект sessionFactory:"
					+ ex.getMessage());
			throw new ExceptionInInitializerError(ex);
		}
	}

	public String getLoginName() {
		return login;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = "Status: " + status;
	}

	public void disconnect() {
		if (!sessionFactory.isClosed()) {
			sessionFactory.close();

			login = null;
			connected = false;
			setStatus("Подключение отключено.");
		}
		if (serviceRegistry != null) {
			StandardServiceRegistryBuilder.destroy(serviceRegistry);
		}
	}

	public static SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public void addStyle(Style style) {
		try {
			HibernateUtil.getStyleDAO().addStyle(style);
		} catch (SQLException e) {
			setStatus(e.getLocalizedMessage());
			e.printStackTrace();
		}
	}

	public void addSong(Song song) {
		try {
			HibernateUtil.getSongDAO().addSong(song);
		} catch (SQLException e) {
			setStatus(e.getLocalizedMessage());
			e.printStackTrace();
		}
	}

	public static Database getInstance() {
		Database localInstance = instance;
		if (localInstance == null) {
			synchronized (Database.class) {
				localInstance = instance;
				if (localInstance == null) {
					instance = localInstance = new Database();
				}
			}
		}
		return localInstance;
	}

	public List<?> getStylesByNameEng(String stylename) {
		List<?> styles = null;
		try {
			styles = HibernateUtil.getStyleDAO().getStyleByNameEng(stylename);
		} catch (SQLException e) {
			setStatus(e.getLocalizedMessage());
			e.printStackTrace();
		}
		return styles;
	}

	public List<?> getStylesByNameRus(String stylename) {
		List<?> styles = null;
		try {
			styles = HibernateUtil.getStyleDAO().getStyleByNameRus(stylename);
		} catch (SQLException e) {
			setStatus(e.getLocalizedMessage());
			e.printStackTrace();
		}
		return styles;
	}

	public List<?> getSongs() {
		List<?> songs = null;
		try {
			songs = HibernateUtil.getSongDAO().getSongs();
		} catch (SQLException e) {
			setStatus(e.getLocalizedMessage());
			e.printStackTrace();
		}
		return songs;
	}

	public List<?> getStyles() {
		List<?> styles = null;
		try {
			styles = HibernateUtil.getStyleDAO().getStyles();
		} catch (SQLException e) {
			setStatus(e.getLocalizedMessage());
			e.printStackTrace();
		}
		return styles;
	}

	public List<?> getLastSongs() {
		List<?> songs = null;
		try {
			songs = HibernateUtil.getSongDAO().getLastSongs();
		} catch (SQLException e) {
			setStatus(e.getLocalizedMessage());
			e.printStackTrace();
		}
		return songs;
	}

	public List<?> getCommentsBySongId(String id) {
		List<?> comments = null;
		try {
			comments = HibernateUtil.getCommentaryDAO().getCommentsBySongId(
					Long.parseLong(id));
		} catch (NumberFormatException | SQLException e) {
			setStatus(e.getLocalizedMessage());
			e.printStackTrace();
		}
		return comments;
	}

	public List<?> getUserByLogin() {
		List<?> user = null;
		try {
			user = HibernateUtil.getUserDAO().getUserByLogin(
					Database.getInstance().getLoginName());
		} catch (SQLException e) {
			setStatus(e.getLocalizedMessage());
			e.printStackTrace();
		}
		return user;
	}

	public Song getSongById(String id) {
		Song song = null;
		try {
			song = HibernateUtil.getSongDAO().getSongById(Long.parseLong(id));
		} catch (NumberFormatException | SQLException e) {
			setStatus(e.getLocalizedMessage());
			e.printStackTrace();
		}
		return song;
	}

	public void addComment(Commentary comment) {
		try {
			HibernateUtil.getCommentaryDAO().addComment(comment);
		} catch (SQLException e) {
			setStatus(e.getLocalizedMessage());
			e.printStackTrace();
		}
	}

	public void updateUser(User user) {
		try {
			HibernateUtil.getUserDAO().updateUser(user);
		} catch (SQLException e) {
			setStatus(e.getLocalizedMessage());
			e.printStackTrace();
		}
	}

	public void deleteSong(Song song) {
		try {
			HibernateUtil.getCommentaryDAO().deleteCommentsBySongId(song.getId());
			HibernateUtil.getSongDAO().deleteSong(song);
		} catch (SQLException e) {
			setStatus(e.getLocalizedMessage());
			e.printStackTrace();
		}
	}

	public Commentary getCommentById(Long id) {
		Commentary comment = null;
		try {
			comment = HibernateUtil.getCommentaryDAO().getCommentById(id);
		} catch (SQLException e) {
			setStatus(e.getLocalizedMessage());
			e.printStackTrace();
		}
		return comment;
	}

	public void deleteComment(Commentary comment) {
		try {
			HibernateUtil.getCommentaryDAO().deleteComment(comment);
		} catch (SQLException e) {
			setStatus(e.getLocalizedMessage());
			e.printStackTrace();
		}
	}

	public List<?> getTopUserList() {
		List<?> users = null;
		try {
			users = HibernateUtil.getUserDAO().getTopUserList();
		} catch (SQLException e) {
			setStatus(e.getLocalizedMessage());
			e.printStackTrace();
		}
		return users;
	}
}