package dao;

import java.sql.SQLException;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tables.Commentary;
import tables.Song;
import courseterm.Database;

public class CommentaryDAOImpl {

	public List<?> getCommentsBySongId(Long id) throws SQLException {
		Session session = null;
		List<?> comments = null;
		try {
			System.out.println("dao:");
			System.out.println("id:" + String.valueOf(id));
			session = Database.getSessionFactory().openSession();
			Song song = HibernateUtil.getSongDAO().getSongById(id);
			Criteria criteria = session.createCriteria(Commentary.class);
			criteria.add(Restrictions.eq("song", song));
			comments = criteria.list();
		} catch (Exception e) {
			e.printStackTrace();
			session.getTransaction().rollback();
		} finally {
			if (session != null && session.isOpen()) {
				session.close();
			}
		}
		return comments;
	}

	public void addComment(Commentary comment) throws SQLException {
		Session session = null;
		try {
			session = Database.getSessionFactory().openSession();
			session.beginTransaction();
			session.saveOrUpdate(comment);
			session.getTransaction().commit();
		} catch (Exception e) {
			e.printStackTrace();
			session.getTransaction().rollback();
		} finally {
			if (session != null && session.isOpen()) {
				session.close();
			}
		}
	}

	public Commentary getCommentById(Long id) throws SQLException {
		Session session = null;
		Commentary comment = null;
		try {
			session = Database.getSessionFactory().openSession();
			comment = (Commentary) session.get(Commentary.class, id);
		} catch (Exception e) {
			e.printStackTrace();
			session.getTransaction().rollback();
		} finally {
			if (session != null && session.isOpen()) {
				session.close();
			}
		}
		return comment;
	}

	public void deleteComment(Commentary comment) throws SQLException {
		Session session = null;
		try {
			session = Database.getSessionFactory().openSession();
			session.beginTransaction();
			comment.getUser().decreaseCommentCount();
			HibernateUtil.getUserDAO().updateUser(comment.getUser());
			session.delete(comment);
			session.getTransaction().commit();
		} catch (Exception e) {
			e.printStackTrace();
			session.getTransaction().rollback();
		} finally {
			if (session != null && session.isOpen()) {
				session.close();
			}
		}
	}

	public void deleteCommentsBySongId(Long id) throws SQLException {
		Session session = null;
		List<?> comments = null;
		try {
			session = Database.getSessionFactory().openSession();
			comments = getCommentsBySongId(id);
			session.beginTransaction();
			for (Object delComment : comments) {
				deleteComment((Commentary) delComment);
			}
			session.getTransaction().commit();
		} catch (Exception e) {
			e.printStackTrace();
			session.getTransaction().rollback();
		} finally {
			if (session != null && session.isOpen()) {
				session.close();
			}
		}
	}

}
