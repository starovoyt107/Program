package dao;

import java.sql.SQLException;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Example;
import org.hibernate.criterion.Order;

import courseterm.Database;
import tables.User;

public class UserDAOImpl {

	public List<?> getUserByLogin(String loginName) throws SQLException {
		Session session = null;
		List<?> users = null;
		try {
			User userExample = new User();
			userExample.setLogin(loginName);
			Example example = Example.create(userExample);
			example.excludeProperty("id");
			example.excludeProperty("email");
			example.excludeProperty("commentCount");
			example.excludeProperty("password");
			session = Database.getSessionFactory().openSession();
			Criteria criteria = session.createCriteria(User.class);
			criteria.add(example);
			users = criteria.list();
		} catch (Exception e) {
			e.printStackTrace();
			session.getTransaction().rollback();
		} finally {
			if (session != null && session.isOpen()) {
				session.close();
			}
		}
		return users;
	}

	public void updateUser(User user) throws SQLException {
		Session session = null;
		try {
			session = Database.getSessionFactory().openSession();
			session.beginTransaction();
			session.update(user);
			session.getTransaction().commit();
		} catch (Exception e) {
			e.printStackTrace();
			session.getTransaction().rollback();
		} finally {
			if (session != null && session.isOpen()) {
				session.close();
			}
		}
	}

	public List<?> getTopUserList() throws SQLException {
		Session session = null;
		List<?> users = null;
		try {
			session = Database.getSessionFactory().openSession();
			users = session.createCriteria(User.class)
					.addOrder(Order.desc("commentCount")).setMaxResults(10).list();
		} catch (Exception e) {
			e.printStackTrace();
			session.getTransaction().rollback();
		} finally {
			if (session != null && session.isOpen()) {
				session.close();
			}
		}
		return users;
	}

}
