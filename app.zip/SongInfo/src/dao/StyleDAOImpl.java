package dao;

import java.sql.SQLException;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Example;
import org.hibernate.criterion.Order;

import courseterm.Database;
import tables.Style;

public class StyleDAOImpl {

	public void addStyle(Style style) throws SQLException {
		Session session = null;
		try {
			session = Database.getSessionFactory().openSession();
			session.beginTransaction();
			session.saveOrUpdate(style);
			session.getTransaction().commit();
		} catch (Exception e) {
			e.printStackTrace();
			session.getTransaction().rollback();
		} finally {
			if (session != null && session.isOpen()) {
				session.close();
			}
		}
	}

	public List<?> getStyleByNameRus(String stylename) throws SQLException {
		Session session = null;
		List<?> styles = null;
		try {
			Style styleExample = new Style();
			styleExample.setNameRus(stylename);
			session = Database.getSessionFactory().openSession();
			Criteria criteria = session.createCriteria(Style.class);
			criteria.add(Example.create(styleExample));
			styles = criteria.list();
		} catch (Exception e) {
			e.printStackTrace();
			session.getTransaction().rollback();
		} finally {
			if (session != null && session.isOpen()) {
				session.close();
			}
		}
		return styles;
	}

	public List<?> getStyleByNameEng(String stylename) throws SQLException {
		Session session = null;
		List<?> styles = null;
		try {
			Style styleExample = new Style();
			styleExample.setNameEng(stylename);
			session = Database.getSessionFactory().openSession();
			Criteria criteria = session.createCriteria(Style.class);
			criteria.add(Example.create(styleExample));
			styles = criteria.list();
		} catch (Exception e) {
			e.printStackTrace();
			session.getTransaction().rollback();
		} finally {
			if (session != null && session.isOpen()) {
				session.close();
			}
		}
		return styles;
	}

	public List<?> getStyles() throws SQLException {
		Session session = null;
		List<?> styles = null;
		try {
			session = Database.getSessionFactory().openSession();
			styles = session.createCriteria(Style.class)
					.addOrder(Order.asc("id")).list();
		} catch (Exception e) {
			e.printStackTrace();
			session.getTransaction().rollback();
		} finally {
			if (session != null && session.isOpen()) {
				session.close();
			}
		}
		return styles;
	}

}
