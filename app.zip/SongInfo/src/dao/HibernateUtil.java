package dao;

public class HibernateUtil{
	private static UserDAOImpl userDAO = null;
	private static StyleDAOImpl styleDAO = null;
	private static SongDAOImpl songDAO = null;
	private static CommentaryDAOImpl commentaryDAO = null;
	private static HibernateUtil instance = null;
	
	public static synchronized HibernateUtil getInstance(){
		if (instance == null){
			instance = new HibernateUtil();
		}
		return instance;
	}
	public static synchronized UserDAOImpl getUserDAO(){
		if (userDAO == null){
			userDAO =  new UserDAOImpl();
		}
		return userDAO;
	}
	
	public static synchronized StyleDAOImpl getStyleDAO(){
		if (styleDAO == null){
			styleDAO = new StyleDAOImpl();
		}
		return styleDAO;
	}
	
	public static synchronized SongDAOImpl getSongDAO(){
		if (songDAO == null){
			songDAO = new SongDAOImpl();
		}
		return songDAO;
	}
	
	public static synchronized CommentaryDAOImpl getCommentaryDAO(){
		if (commentaryDAO == null){
			commentaryDAO = new CommentaryDAOImpl();
		}
		return commentaryDAO;
	}
	
}

