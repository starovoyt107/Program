package dao;

import java.sql.SQLException;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.Order;

import tables.Song;
import courseterm.Database;

public class SongDAOImpl {

	public void addSong(Song song) throws SQLException {
		Session session = null;
		try {
			session = Database.getSessionFactory().openSession();
			session.beginTransaction();
			session.saveOrUpdate(song);
			session.getTransaction().commit();
		} catch (Exception e) {
			e.printStackTrace();
			session.getTransaction().rollback();
		} finally {
			if (session != null && session.isOpen()) {
				session.close();
			}
		}
	}

	public List<?> getLastSongs() throws SQLException {
		Session session = null;
		List<?> songs = null;
		try {
			session = Database.getSessionFactory().openSession();
			songs = session.createCriteria(Song.class)
					.addOrder(Order.desc("id")).setMaxResults(10).list();
		} catch (Exception e) {
			e.printStackTrace();
			session.getTransaction().rollback();
		} finally {
			if (session != null && session.isOpen()) {
				session.close();
			}
		}
		return songs;
	}

	public List<?> getSongs() throws SQLException {
		Session session = null;
		List<?> songs = null;
		try {
			session = Database.getSessionFactory().openSession();
			songs = session.createCriteria(Song.class)
					.addOrder(Order.asc("id")).list();
		} catch (Exception e) {
			e.printStackTrace();
			session.getTransaction().rollback();
		} finally {
			if (session != null && session.isOpen()) {
				session.close();
			}
		}
		return songs;
	}

	public Song getSongById(long id) throws SQLException {
		Session session = null;
		Song song = null;
		try {
			session = Database.getSessionFactory().openSession();
			song = (Song) session.get(Song.class, id);
		} catch (Exception e) {
			e.printStackTrace();
			session.getTransaction().rollback();
		} finally {
			if (session != null && session.isOpen()) {
				session.close();
			}
		}
		return song;
	}
	
	public void deleteSong(Song song) throws SQLException{
		Session session = null;
		try {
			session = Database.getSessionFactory().openSession();
			session.beginTransaction();
			session.delete(song);
			session.getTransaction().commit();
		} catch (Exception e) {
			e.printStackTrace();
			session.getTransaction().rollback();
		} finally {
			if (session != null && session.isOpen()) {
				session.close();
			}
		}
	}
}
