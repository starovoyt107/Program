package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import tables.User;

import courseterm.Database;

public class TopListServlet extends HttpServlet {
	private static final long serialVersionUID = -7549057521467567360L;
	private Database database = Database.getInstance();
	private String homeUrl = "http://localhost:8080/SongInfo/";

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) {

	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html; charset=UTF-8");
		PrintWriter out = response.getWriter();
		if (!database.connected) {
			out.write("Сначала вводите в систему");
			response.setHeader("Refresh", "2; URL=" + homeUrl);
			return;
		}
		List<?> users = database.getTopUserList();
		if (users == null || users.size() == 0) {
			out.write("<tr><td>Песни не найдены</td><tr>");
			return;
		}
		int i = 0;
		for (Object user : users) {
			i++;
			out.println("<tr><td>" + String.valueOf(i) + "<td>"
					+ ((User) user).getLogin() + "</td><td>"
					+ ((User) user).getCommentCount() + "</td>");
		}
	}
}
