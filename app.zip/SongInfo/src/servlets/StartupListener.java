package servlets;

import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Enumeration;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import courseterm.Database;

public class StartupListener implements ServletContextListener {

	private Database database = Database.getInstance();
	private static String nameOfLogger = StartupListener.class.getName();
	private static Logger logger = Logger.getLogger(nameOfLogger);

	@Override
	public void contextInitialized(ServletContextEvent sce) {
		System.out.println("Context initialized");
	}

	@Override
	public void contextDestroyed(ServletContextEvent sce) {
		if (database.connected)
			database.disconnect();
		Enumeration<Driver> drivers = DriverManager.getDrivers();
		while (drivers.hasMoreElements()) {
			Driver driver = drivers.nextElement();
			try {
				DriverManager.deregisterDriver(driver);
				logger.log(Level.INFO,
						String.format("Deregistering jdbc driver: %s", driver));
			} catch (SQLException e) {
				logger.log(Level.SEVERE,
						String.format("Error deregistering driver %s", driver),
						e);
			}
		}
		System.out.println("Context destroyed");
	}

}
