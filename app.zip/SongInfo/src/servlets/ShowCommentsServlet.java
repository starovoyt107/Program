package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import courseterm.Database;
import tables.Commentary;
import tables.Song;
import tables.User;

public class ShowCommentsServlet extends HttpServlet {
	private static final long serialVersionUID = 8755865697168178068L;
	private static Database database = Database.getInstance();
	private String homeUrl = "http://localhost:8080/SongInfo/";

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html; charset=UTF-8");
		PrintWriter out = response.getWriter();
		if (!database.connected) {
			out.write("Сначала вводите в систему");
			response.setHeader("Refresh", "2; URL=" + homeUrl);
			return;
		}
		String id = request.getParameter("id");
		if (id.isEmpty()) {
			out.write("Id песни не указан");
			return;
		}
		Long longId = Long.parseLong(id);
		Song song = database.getSongById(id);
		if (song == null){
			out.write("Нет такой песни");
			return;
		}
		List<?> comments = database.getCommentsBySongId(id);
		if ((comments == null) || (comments.size() == 0)
				|| ((Commentary) comments.get(0)).getSong().getId() != longId) {
			out.write("<tr><td><b>Комментариев к этой песне нет</b></td></tr>");
			return;
		}
		out.println("<tr><td><b>Список коментариев к песне "
				+ ((Commentary) comments.get(0)).getSong().toString()
				+ ":</b></td></tr>");
		Iterator<?> it = comments.iterator();
		Long i = (long) 0;
		List<?> users = database.getUserByLogin();
		if (users.size() == 0) {
			out.write("Вход не выполнен");
			return;
		}
		User user = (User) users.iterator().next();
		while (it.hasNext()) {
			Commentary comment = (Commentary) it.next();
			i++;
			out.println("<tr><td><b>Коментарий #" + String.valueOf(i)
					+ " Добавлен пользователем:</b></td><td>"
					+ comment.getUser().toString());
			if (comment.getUser().equals(user)) {
				out.println("<td><img id='"
						+ comment.getId()
						+ "' src=\""
						+ homeUrl
						+ "rc/img/del.png\" onclick=\"deletecomment(this.id);\"></td>");
			} else
				out.println("<td></td>");
			out.println("</td></tr><tr><td>" + comment.getComment()
					+ "</td></tr><tr></tr>");
		}
	}
}
