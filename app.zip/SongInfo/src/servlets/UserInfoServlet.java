package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import tables.User;

import courseterm.Database;

public class UserInfoServlet extends HttpServlet {
	private static final long serialVersionUID = -4998458832672417426L;
	private static Database database = Database.getInstance();

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html; charset=UTF-8");
		PrintWriter out = response.getWriter();
		out.write("<head><link rel=\"shortcut icon\" href=\"favicon.ico\" /></head>");
		List<?> users = database.getUserByLogin();
		if (users.size() == 0) {
			out.write("Вход не выполнен");
			return;
		}
		User user = (User) users.iterator().next();
		out.println("<table><tr><td>Имя:</td><td>"
				+ user.getLogin()
				+ "</td></tr><tr><td>E-mail:</td><td>"
				+ user.getEmail()
				+ "</td></tr><tr><td>Количество добавленных коментариев</td><td>"
				+ Long.toString(user.getCommentCount()) + "</td></tr></table>");
	}
}
