package servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import courseterm.Database;

public class LoginServlet extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 7638796169158385551L;
	private Database database = Database.getInstance();
	private String homeUrl = "http://localhost:8080/SongInfo/";
	private String css1 = "<link type=\"text/css\" rel=\"stylesheet\" href=\"http://localhost:8080/SongInfo/css/global.css\"/>";
	private String css2 = "<link type=\"text/css\" rel=\"stylesheet\" href=\"http://localhost:8080/SongInfo/css/login.css\"/>";

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		out.write("<html><head></head><body>");
		out.write("<div id=\"connected\">");
		if (database.connected) {
			out.write("true");
		} else {
			out.write("false");
		}
		out.write("</div>");
		out.write("</body></html>");
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html; charset=UTF-8");
		PrintWriter out = response.getWriter();
		out.println(css1);
		out.println(css2);
		out.println("<div class='center'>");
		String submitLogin = request.getParameter("submitLogin");
		String login = request.getParameter("login");
		String pass = request.getParameter("password");
		String logoutsub = request.getParameter("logoutsub");
		if (submitLogin != null) {
			if (!submitLogin.isEmpty()) {
				if (login.isEmpty() || pass.isEmpty()) {
					out.write("Некоторые поля не заполнены, перенаправляю на домашнюю страницу...");
					out.println("</div>");
					response.setHeader("Refresh", "3; URL=" + homeUrl);
					return;
				}
				try {
					database.connect(login, pass);
					out.write("Вход успешен! <br>");
					out.write("Привет " + database.getLoginName() + " !<br>");
					out.write("Перенаправление на главную страницу через 3 секунды...");
					out.println("</div>");
					response.setHeader("Refresh", "3; URL=" + homeUrl
							+ "main.jsp");
				} catch (ExceptionInInitializerError ex) {
					out.write("Введенный логин или пароль не правильный");
					out.write("<br>Перенаправление на главную страницу через 3 секунды...");
					out.println("</div>");
					response.setHeader("Refresh", "3; URL=" + homeUrl
							+ "main.jsp");
				}
			}
		} else if (!logoutsub.isEmpty()) {
			if (database.connected)
				database.disconnect();
			out.write("Выход из системы успешен, перенаправление на домашнюю страницу через 3 секунды...");
			out.println("</div>");
			response.setHeader("Refresh", "3; URL=" + homeUrl);
		}
	}
}