package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import tables.Song;
import tables.User;
import courseterm.Database;

public class LastSongListServlet extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = -1612210811015698397L;
	private static Database database = Database.getInstance();
	private String homeUrl = "http://localhost:8080/SongInfo/";

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html; charset=UTF-8");
		PrintWriter out = response.getWriter();
		if (!database.connected) {
			out.write("Сначала вводите в систему");
			response.setHeader("Refresh", "2; URL=" + homeUrl);
			return;
		}
		List<?> songs = database.getLastSongs();
		if ((songs == null) || songs.size() == 0) {
			out.write("<tr><td>Песни не найдены</td><tr>");
			return;
		}
		List<?> users = database.getUserByLogin();
		if (users.size() == 0) {
			out.write("Вход не выполнен");
			return;
		}
		User user = (User) users.iterator().next();
		out.write("<tr><th>Исполнитель</th><th>Название песни</th>"
				+ "<th>Стиль</th><th>Длинна трека</th><th>Добавлен пользователем</th><th>Комментарии</th><th>Удалить</th></tr>");
		Iterator<?> it = songs.iterator();
		while (it.hasNext()) {
			Song song = (Song) it.next();
			out.println("<tr><td>" + song.getPerformer() + "</td><td>"
					+ song.getName() + "</td><td>" + song.getStyle().toString()
					+ "</td><td>" + song.getTrackLength() + "</td><td>"
					+ song.getUser().toString() + "</td><td><img src=\""
					+ homeUrl + "/rc/img/c.jpg\" id=" + song.getId()
					+ " onclick=\"showcomments(this.id);\">");
			if (song.getUser().equals(user)) {
				out.println("<td><img id="
						+ song.getId()
						+ " src=\""
						+ homeUrl
						+ "rc/img/del.png\" onclick=\"deletesong(this.id);\"></td>");
			} else
				out.println("<td></td>");
			out.println("</td></tr>");
		}
	}
}
