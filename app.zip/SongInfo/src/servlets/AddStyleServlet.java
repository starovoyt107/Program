package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import tables.Style;

import courseterm.Database;

public class AddStyleServlet extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = -1927009230726072070L;
	private Database database = Database.getInstance();
	private String addUrl = "http://localhost:8080/SongInfo/addstyle.jsp";
	private String homeUrl = "http://localhost:8080/SongInfo/";

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) {
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html; charset=UTF-8");
		PrintWriter out = response.getWriter();
		if (!database.connected) {
			out.write("Сначала вводите в систему");
			response.setHeader("Refresh", "2; URL=" + homeUrl);
			return;
		}
		String stylerusname = request.getParameter("stylerusname");
		String styleengname = request.getParameter("styleengname");
		if (stylerusname.isEmpty() || styleengname.isEmpty()) {
			out.write("Некоторые поля не заполнены");
			response.setHeader("Refresh", "2; URL=" + addUrl);
			return;
		}
		List<?> users = database.getUserByLogin();
		if (users.size() == 0) {
			out.println("Вход не выполнен");
			response.setHeader("Refresh", "2; URL=" + homeUrl);
			return;
		}
		Style style = new Style(stylerusname, styleengname);
		database.addStyle(style);
		out.println("Стиль успешно добавлен");
		response.setHeader("Refresh", "2; URL=" + addUrl);
	}
}
