package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import tables.Commentary;
import tables.User;

import courseterm.Database;

public class DeleteCommentServlet extends HttpServlet {
	private static final long serialVersionUID = 4255058350676177089L;
	private static Database database = Database.getInstance();
	private String homeUrl = "http://localhost:8080/SongInfo/";

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) {

	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html; charset=UTF-8");
		PrintWriter out = response.getWriter();
		if (!database.connected) {
			out.write("Сначала вводите в систему");
			response.setHeader("Refresh", "2; URL=" + homeUrl);
			return;
		}
		String id = request.getParameter("id");
		if (id.isEmpty()) {
			out.write("Id комментария не указан");
			return;
		}
		List<?> users = database.getUserByLogin();
		if (users.size() == 0) {
			out.println("Вход не выполнен");
			response.setHeader("Refresh", "2; URL=" + homeUrl);
			return;
		}
		Long longId = Long.parseLong(id);
		Commentary comment = database.getCommentById(longId);
		if (comment == null || comment.getId()!=longId) {
			out.println("Такой коментарий не найден");
			return;
		}
		User user = (User) users.iterator().next();
		if (!comment.getUser().equals(user)) {
			out.println("Нельзя удалять чужие комментарии");
			return;
		}
		database.deleteComment(comment);
		out.println("Комментарий успешно удален");
	}
}
