package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import tables.Song;
import tables.Style;
import tables.User;

import courseterm.Database;

public class AddSongServlet extends HttpServlet {

	private static final long serialVersionUID = -7642890183054317412L;
	private static Database database = Database.getInstance();
	private String homeUrl = "http://localhost:8080/SongInfo/";
	private String addUrl = "http://localhost:8080/SongInfo/addsong.jsp";

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) {
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html; charset=UTF-8");
		PrintWriter out = response.getWriter();
		if (!database.connected) {
			out.write("Сначала вводите в систему");
			response.setHeader("Refresh", "2; URL=" + homeUrl);
			return;
		}

		String songname = request.getParameter("songname");
		String performer = request.getParameter("performer");
		String tracklength = request.getParameter("tracklength");
		String stylename = request.getParameter("style");
		if (songname.isEmpty() || performer.isEmpty() || tracklength.isEmpty()
				|| stylename.isEmpty()) {
			out.write("Некоторые поля не заполнены");
			response.setHeader("Refresh", "2; URL=" + addUrl);
			return;
		}
		List<?> users = database.getUserByLogin();
		if (users.size() == 0) {
			out.println("Вход не выполнен");
			response.setHeader("Refresh", "2; URL=" + homeUrl);
			return;
		}
		User user = (User) users.iterator().next();
		List<?> styles = database.getStylesByNameEng(stylename);
		if (styles.size() == 0) {
			styles = database.getStylesByNameRus(stylename);
			if (styles.size() == 0) {
				out.println("Указаный стиль не найден");
				response.setHeader("Refresh", "2; URL=" + addUrl);
				return;
			}
		}
		Style style = (Style) styles.iterator().next();
		Song song = new Song(songname, performer, tracklength, style, user);
		database.addSong(song);
		out.println("Песня успешно добавлена");
		response.setHeader("Refresh", "2; URL=" + addUrl);
	}
}
