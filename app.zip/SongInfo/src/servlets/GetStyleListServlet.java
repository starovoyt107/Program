package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import tables.Style;
import courseterm.Database;

public class GetStyleListServlet extends HttpServlet {
	private static final long serialVersionUID = 3827786092647900465L;
	private static Database database = Database.getInstance();
	private String homeUrl = "http://localhost:8080/SongInfo/";

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html; charset=UTF-8");
		PrintWriter out = response.getWriter();
		if (!database.connected) {
			out.write("Сначала вводите в систему");
			response.setHeader("Refresh", "2; URL=" + homeUrl);
			return;
		}
		List<?> styles = database.getStyles();
		if ((styles == null) || styles.size() == 0) {
			out.write("<tr><td>Стили не найдены</td><tr>");
			return;
		}
		out.write("<tr><td>Название cтиля (рус)</td><td>Название стиля (англ)</td></tr>");
		Iterator<?> it = styles.iterator();
		while (it.hasNext()) {
			Style style = (Style) it.next();
			out.println("<tr><td>" + style.getNameRus() + "</td><td>"
					+ style.getNameEng() + "</td></tr>");
		}
	}
}
