$(document).ready(function() {
	$.ajax({
		type: 'POST',
		url: 'getstylelist',
		success: function(result){
			$('#list').html(result);
		}
	});
});