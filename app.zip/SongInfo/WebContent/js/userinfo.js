$(document).ready(function() {
	$.ajax({
		type: 'POST',
		url: 'getuserinfo',
		success: function(result){
			$('#info').html(result);
		}
	});
});