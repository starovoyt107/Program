$(document).ready(function() {
	$.ajax({
		type: 'POST',
		url: 'topsonglist',
		success: function(result){
			$('#list').html(result);
		}
	});
});