function sendcomments() {
	var idnumber = window.location.hash.replace('#id', "");
	$.ajax({
		type : 'POST',
		data : {
			'id' : idnumber,
			'comment' : $('#comment').val()
		},
		url : 'submitcomment',
		success : function(result) {
			$('#result').empty();
			$('#result').append('Коментарий успешно добавлен.');
			setTimeout(function() {
				location.reload();
			}, 2000);
		},
		error : function(){
			$('#result').empty();
			$('#result').append('Не удалось добавить комментарий');
		}
	});
}