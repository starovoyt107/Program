$(document).ready(function() {
	$('#illegalid').hide();
	$('#properid').hide();
	var idnumber = window.location.hash.replace('#id', "");
	if (idnumber <= 0) {
		$('#illegalid').show();
		window.setTimeout(function() {
			window.location.href = 'http://localhost:8080/SongInfo';
		}, 2000);
	}
	$('#properid').show();
	$.ajax({
		type : 'POST',
		data : {
			'id' : idnumber
		},
		url : 'deletecomment',
		success : function(result) {
			$('#properid').html(result);
		}
	});
});