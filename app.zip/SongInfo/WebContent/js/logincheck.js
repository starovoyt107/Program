$(document).ready(function() {
			$('#notlogined').hide();
			$('#logined').hide();

			$.ajax({
				type : 'GET',
				url : 'login',
				success : function(reply) {
					var parsedanswer = $(reply).html();
					if (parsedanswer == "true") {
						$('#logined').show();
						window.setTimeout(function() {
						    window.location.href = 'http://localhost:8080/SongInfo/main.jsp';
						}, 3000);
					} else if (parsedanswer == "false") {
						$('#notlogined').show();
					}
				}
			});
		});