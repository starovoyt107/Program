$(document).ready(function() {
	$.ajax({
		type : 'GET',
		url : 'login',
		success : function(reply) {
			var parsedanswer = $(reply).html();
			if (parsedanswer == "false") {
				$('#notloginned').show();
				window.setTimeout(function() {
					window.location.href = 'http://localhost:8080/SongInfo/';
				}, 0);
			}
		}
	});
});