$(document).ready(function() {
	$.ajax({
		type: 'POST',
		url: 'getsonglist',
		success: function(result){
			$('#list').html(result);
		}
	});
});