package lab2;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JTable;

import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.JScrollPane;

public class GI extends JFrame {

	private JPanel contentPane;
	private final JTextField textField = new JTextField();
	private final JButton btnNewButton = new JButton("Go");
	private final JLabel lblNewLabel = new JLabel("SQL");
	private Statement select = null;
	private final JScrollPane scrollPane = new JScrollPane();
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GI frame = new GI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public GI() {
		
		try {
		//	Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
			Class.forName("org.postgresql.Driver");
			String url = "jdbc:postgresql://localhost:5432/Music";
			String userName = "postgres";
			String password = "q";
			try {
				Connection connect = DriverManager.getConnection(url, userName, password);
				 select = connect.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		//DefaultTableModel model = null;
		JTable table = new JTable();
		
		setTitle("\u041B\u04202: \u041F\u0443\u0441\u0442\u0438\u0439, \u0421\u0442\u0430\u0440\u043E\u0432\u043E\u0439\u0442");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		GridBagLayout gbl_contentPane = new GridBagLayout();
		gbl_contentPane.columnWidths = new int[]{33, 284, 89, 0};
		gbl_contentPane.rowHeights = new int[]{20, 186, 0};
		gbl_contentPane.columnWeights = new double[]{0.0, 1.0, 0.0, Double.MIN_VALUE};
		gbl_contentPane.rowWeights = new double[]{0.0, 0.0, Double.MIN_VALUE};
		contentPane.setLayout(gbl_contentPane);
		GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
		gbc_lblNewLabel.fill = GridBagConstraints.BOTH;
		gbc_lblNewLabel.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel.gridx = 0;
		gbc_lblNewLabel.gridy = 0;
		contentPane.add(lblNewLabel, gbc_lblNewLabel);
		GridBagConstraints gbc_textField = new GridBagConstraints();
		gbc_textField.anchor = GridBagConstraints.NORTH;
		gbc_textField.fill = GridBagConstraints.HORIZONTAL;
		gbc_textField.insets = new Insets(0, 0, 5, 5);
		gbc_textField.gridx = 1;
		gbc_textField.gridy = 0;
		contentPane.add(textField, gbc_textField);
		textField.setColumns(10);
		GridBagConstraints gbc_btnNewButton = new GridBagConstraints();
		gbc_btnNewButton.fill = GridBagConstraints.BOTH;
		gbc_btnNewButton.insets = new Insets(0, 0, 5, 0);
		gbc_btnNewButton.gridx = 2;
		gbc_btnNewButton.gridy = 0;
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String sql = textField.getText();
				if(sql.toUpperCase().startsWith("SELECT")){
					try {
						ResultSet rs = select.executeQuery(sql);
					rs.last();
					int r = rs.getRow();
					rs.beforeFirst();
					DefaultTableModel model = new DefaultTableModel(r, 5);
					int i = 0;
					while(rs.next()){
						model.setValueAt(rs.getInt(1), i, 0);
						model.setValueAt(rs.getString(2), i, 1);
						model.setValueAt(rs.getString(3), i, 2);
						model.setValueAt(rs.getString(4), i, 3);
						model.setValueAt(rs.getString(5), i, 4);
						i++;
					}
					//model.setValueAt("20", i, 4);
					table.setModel(model);
					scrollPane.setViewportView(table);
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				else if(sql.startsWith("INSERT") || sql.startsWith("UPDATE") || sql.startsWith("DELETE"))
				{try {
					select.executeUpdate(sql);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				}else {
					JOptionPane.showConfirmDialog(null, "������ ���������� � ������������ ����������", "Error", JOptionPane.CLOSED_OPTION);
				}
			}
		});
		contentPane.add(btnNewButton, gbc_btnNewButton);
		
		GridBagConstraints gbc_scrollPane = new GridBagConstraints();
		gbc_scrollPane.gridwidth = 3;
		gbc_scrollPane.insets = new Insets(0, 0, 0, 5);
		gbc_scrollPane.fill = GridBagConstraints.BOTH;
		gbc_scrollPane.gridx = 0;
		gbc_scrollPane.gridy = 1;
		contentPane.add(scrollPane, gbc_scrollPane);
		
		scrollPane.setViewportView(table);
	}

}
